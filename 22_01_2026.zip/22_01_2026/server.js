const express = require("express");
const mongoose = require("mongoose");

const app = express();
app.use(express.json());

// 1. Connect MongoDB
mongoose.connect("mongodb://127.0.0.1:27017/eventDB")
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

// 2. Event Schema
const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  location: {
    type: String,
    required: true
  },
  participants: {
    type: Number,
    required: true,
    min: 0
  }
});

// 3. Model
const Event = mongoose.model("Event", eventSchema);

// ================= CRUD =================

// CREATE
app.post("/events", async (req, res) => {
  const event = new Event(req.body);
  await event.save();
  res.json(event);
});

// READ
app.get("/events", async (req, res) => {
  const events = await Event.find();
  res.json(events);
});

// UPDATE
app.put("/events/:id", async (req, res) => {
  const event = await Event.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true }
  );
  res.json(event);
});

// DELETE
app.delete("/events/:id", async (req, res) => {
  await Event.findByIdAndDelete(req.params.id);
  res.json({ message: "Event deleted" });
});

// 4. Start Server
app.listen(3000, () => {
  console.log("Server running on port 3000");
  console.log("Click here → http://localhost:3000/events");
});


