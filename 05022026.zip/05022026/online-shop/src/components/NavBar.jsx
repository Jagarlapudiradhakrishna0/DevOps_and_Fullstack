import { NavLink } from "react-router-dom";

function NavBar() {
  return (
    <header className="navbar">
      <div className="logo">
        RK<span>STORE</span>
      </div>

      <nav className="nav-links">
        <NavLink to="/" className="nav-btn">
          Home
        </NavLink>
        <NavLink to="/products" className="nav-btn">
          Products
        </NavLink>
        <NavLink to="/cart" className="nav-btn">
          Cart
        </NavLink>
      </nav>
    </header>
  );
}

export default NavBar;
