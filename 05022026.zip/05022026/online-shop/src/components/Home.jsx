import { Link } from "react-router-dom";

function Home() {
  return (
    <section className="hero">
      <div className="hero-content">
        <h1>Welcome to OnlineShop</h1>

        <p className="hero-sub">
          Discover the latest tech products at unbeatable prices
        </p>

        <p className="hero-desc">
          Premium electronics, gadgets, and accessories for your digital lifestyle
        </p>

        <Link to="/products" className="hero-btn">
          Shop Now →
        </Link>
      </div>

      <div className="hero-image">
        <img
          src="https://images.unsplash.com/photo-1523275335684-37898b6baf30"
          alt="Shopping"
        />
      </div>
    </section>
  );
}

export default Home;
