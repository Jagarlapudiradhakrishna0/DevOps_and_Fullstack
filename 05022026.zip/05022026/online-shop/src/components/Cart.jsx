import { useCart } from "./cartContext";


function Cart() {
  const { cart } = useCart();

  if (cart.length === 0)
    return <div className="empty-state">Your cart is empty 🛒</div>;

  const total = cart.reduce((sum, i) => sum + i.price, 0);

  return (
    <div className="container">
      <h2>Shopping Cart</h2>

      {cart.map((item, i) => (
        <div key={i} className="detail-card" style={{ marginTop: "15px" }}>
          <h3>{item.name}</h3>
          <p>₹{item.price}</p>
        </div>
      ))}

      <h3 style={{ marginTop: "20px" }}>Total: ₹{total}</h3>
    </div>
  );
}

export default Cart;
