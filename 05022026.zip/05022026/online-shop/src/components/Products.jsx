import { Link, Outlet } from "react-router-dom";
import { products } from "../features/products/productsData";

function Products() {
  return (
    <div className="container">
      <h1 className="products-title">Products</h1>

      <div className="products-layout">
        {/* LEFT : PRODUCT GRID */}
        <div className="product-grid">
          {products.map((p) => (
            <div key={p.id} className="product-card">
              {/* Image */}
              <div className="product-image">
                <img src={p.image} alt={p.name} />
                <span className="badge">{p.category}</span>
              </div>

              {/* Content */}
              <div className="product-content">
                <h3>{p.name}</h3>
                <p className="price">
                  ₹{p.price.toLocaleString("en-IN")}
                </p>

                {/* Feature chips */}
                <div className="features">
                  <span>Premium</span>
                  <span>Warranty</span>
                </div>

                {/* CTA */}
                <Link to={p.id} className="card-btn">
                  View Details
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* RIGHT : DETAIL PANEL */}
        <div className="product-detail-panel">
          <Outlet />
        </div>
      </div>
    </div>
  );
}

export default Products;
