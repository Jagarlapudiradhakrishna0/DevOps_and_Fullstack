import { useParams } from "react-router-dom";
import { products } from "../features/products/productsData";
import { useCart } from "./cartContext";

function ProductDetail() {
  const { id } = useParams();
  const { addToCart } = useCart();

  const product = products.find((p) => p.id === id);

  if (!product) {
    return (
      <div className="empty-state">
        <p>Select a product to see details</p>
      </div>
    );
  }

  return (
    <div className="detail-card">
      <img src={product.image} alt={product.name} />

      <div className="detail-content">
        <h2>{product.name}</h2>
        <p className="detail-desc">{product.description}</p>
        <p className="detail-price">₹{product.price}</p>

        <button
          className="btn-primary"
          onClick={() => addToCart(product)}
        >
          Add to Cart
        </button>
      </div>
    </div>
  );
}

export default ProductDetail;
