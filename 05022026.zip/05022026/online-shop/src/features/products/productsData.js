import macbook from "../../assets/images/macbook.jpg";
import iphone from "../../assets/images/iphone.jpeg";
import sony from "../../assets/images/sony-headphones.jpeg";

export const products = [
  {
    id: "lap-101",
    name: "MacBook Pro M3",
    price: 189999,
    description: "Apple M3 chip, 16GB RAM, 512GB SSD",
    image: macbook,
    category: "Laptop",
  },
  {
    id: "mob-202",
    name: "iPhone 15",
    price: 79999,
    description: "A16 Bionic chip, Pro camera system",
    image: iphone,
    category: "Mobile",
  },
  {
    id: "hed-303",
    name: "Sony WH-1000XM5",
    price: 19999,
    description: "Industry-leading noise cancellation",
    image: sony,
    category: "Audio",
  },
];
