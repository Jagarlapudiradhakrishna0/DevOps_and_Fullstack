const app = require('./app');

const PORT = 3000;

app.listen(PORT, () => {
  console.log('-----------------------------------');
  console.log('🚀 Student Management System Server');
  console.log('-----------------------------------');
  console.log(`Server running at: http://localhost:${PORT}`);
  console.log('');
  console.log('Available API Endpoints:');
  console.log(`Home     → http://localhost:${PORT}/`);
  console.log(`Students → http://localhost:${PORT}/students`);
  console.log(`Register → http://localhost:${PORT}/students/register`);
  console.log(`Courses  → http://localhost:${PORT}/courses`);
  console.log(`Results  → http://localhost:${PORT}/results/1`);
  console.log('-----------------------------------');
});
