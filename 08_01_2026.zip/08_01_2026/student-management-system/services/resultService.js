const results = {
  1: { Math: "A", Physics: "B" },
  2: { Math: "B+", CS: "A" }
};

exports.getStudentResults = (studentId) => {
  return results[studentId] || "No Results Found";
};
