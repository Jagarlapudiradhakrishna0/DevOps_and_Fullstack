const courses = ["Math", "Physics", "Computer Science"];

exports.getAllCourses = () => courses;
