const express = require('express');
const app = express();

app.use(express.json());

app.get('/', (req, res) => {
  res.send('Product Management API Running');
});

app.use('/products', require('./routes/productRoutes'));

module.exports = app;
