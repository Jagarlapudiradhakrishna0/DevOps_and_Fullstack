const app = require('./app');
const connectDB = require('./config/db');

const PORT = 3000;

connectDB();

app.listen(PORT, () => {
  console.log('-----------------------------');
  console.log(`Server: http://localhost:${PORT}`);
  console.log('POST    /products');
  console.log('GET     /products');
  console.log('GET     /products/:id');
  console.log('PUT     /products/:id');
  console.log('DELETE  /products/:id');
  console.log('-----------------------------');
});
