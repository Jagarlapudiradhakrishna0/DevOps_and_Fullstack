const Product = require('../models/productModel');

exports.createProduct = (data) => {
  return Product.create(data);
};

exports.getAllProducts = () => {
  return Product.find();
};

exports.getProductById = (id) => {
  return Product.findById(id);
};

exports.updateProduct = (id, data) => {
  return Product.findByIdAndUpdate(id, data, { new: true });
};

exports.deleteProduct = (id) => {
  return Product.findByIdAndDelete(id);
};
