const express = require('express');
const cors = require('cors');
const app = express();
const port = 5000;

app.use(express.json());
app.use(cors());

let expenses = [
  { id: 1, name: 'Groceries', amount: 50, category: 'Food', date: new Date().toISOString().split('T')[0], notes: 'Weekly shopping' },
  { id: 2, name: 'Gas', amount: 30, category: 'Transport', date: new Date().toISOString().split('T')[0], notes: 'Fuel refill' },
];

// GET all expenses with optional filtering
app.get('/api/expenses', (req, res) => {
  const { category, startDate, endDate, search } = req.query;
  let filtered = [...expenses];

  if (category) {
    filtered = filtered.filter(e => e.category === category);
  }

  if (search) {
    filtered = filtered.filter(e => 
      e.name.toLowerCase().includes(search.toLowerCase()) ||
      e.notes.toLowerCase().includes(search.toLowerCase())
    );
  }

  if (startDate) {
    filtered = filtered.filter(e => new Date(e.date) >= new Date(startDate));
  }

  if (endDate) {
    filtered = filtered.filter(e => new Date(e.date) <= new Date(endDate));
  }

  // Sort by date descending
  filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
  res.json(filtered);
});

// GET statistics
app.get('/api/statistics', (req, res) => {
  const byCategory = {};
  let totalAmount = 0;

  expenses.forEach(e => {
    totalAmount += e.amount;
    byCategory[e.category] = (byCategory[e.category] || 0) + e.amount;
  });

  res.json({
    total: totalAmount,
    count: expenses.length,
    average: expenses.length > 0 ? totalAmount / expenses.length : 0,
    byCategory,
  });
});

// GET available categories
app.get('/api/categories', (req, res) => {
  const categories = ['Food', 'Transport', 'Entertainment', 'Utilities', 'Shopping', 'Healthcare', 'Other'];
  res.json(categories);
});

// POST new expense
app.post('/api/expenses', (req, res) => {
  const { name, amount, category, date, notes } = req.body;
  
  if (!name || !amount || !category || !date) {
    return res.status(400).json({ error: 'Name, amount, category, and date are required' });
  }

  if (typeof name !== 'string' || name.trim() === '') {
    return res.status(400).json({ error: 'Name must be a non-empty string' });
  }

  const parsedAmount = parseFloat(amount);
  if (isNaN(parsedAmount) || parsedAmount <= 0) {
    return res.status(400).json({ error: 'Amount must be a positive number' });
  }

  const newExpense = {
    id: Math.max(...expenses.map(e => e.id), 0) + 1,
    name: name.trim(),
    amount: parsedAmount,
    category: category.trim(),
    date: date,
    notes: notes ? notes.trim() : '',
  };

  expenses.push(newExpense);
  res.status(201).json(newExpense);
});

// PUT update expense
app.put('/api/expenses/:id', (req, res) => {
  const { id } = req.params;
  const { name, amount, category, date, notes } = req.body;
  
  const expense = expenses.find(e => e.id === parseInt(id));
  if (!expense) {
    return res.status(404).json({ error: 'Expense not found' });
  }

  if (name) expense.name = name.trim();
  if (amount) expense.amount = parseFloat(amount);
  if (category) expense.category = category.trim();
  if (date) expense.date = date;
  if (notes !== undefined) expense.notes = notes.trim();

  res.json(expense);
});

// DELETE expense
app.delete('/api/expenses/:id', (req, res) => {
  const { id } = req.params;
  const index = expenses.findIndex(e => e.id === parseInt(id));
  
  if (index === -1) {
    return res.status(404).json({ error: 'Expense not found' });
  }

  const deleted = expenses.splice(index, 1);
  res.json(deleted[0]);
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
