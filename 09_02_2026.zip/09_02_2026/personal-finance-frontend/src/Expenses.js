import React, { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import './Expenses.css';

// Category color map
const CATEGORY_COLORS = {
  'Food': '#f59e0b',
  'Transport': '#3b82f6',
  'Entertainment': '#ec4899',
  'Utilities': '#10b981',
  'Shopping': '#8b5cf6',
  'Healthcare': '#ef4444',
  'Other': '#6b7280',
};

const Expenses = () => {
  // State Management
  const [expenses, setExpenses] = useState([]);
  const [categories, setCategories] = useState([]);
  const [expenseData, setExpenseData] = useState({ 
    name: '', 
    amount: '', 
    category: 'Food',
    date: new Date().toISOString().split('T')[0],
    notes: ''
  });
  const [editingId, setEditingId] = useState(null);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState('');
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState('date');
  const [filterDateRange, setFilterDateRange] = useState({ start: '', end: '' });
  const [showStats, setShowStats] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  // Load expenses and categories on mount
  useEffect(() => {
    fetchExpenses();
    fetchCategories();
  }, []);

  // Auto-clear messages
  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => setMessage(''), 3000);
      return () => clearTimeout(timer);
    }
  }, [message]);

  const fetchExpenses = async () => {
    try {
      setLoading(true);
      const response = await axios.get('http://localhost:5000/api/expenses');
      setExpenses(response.data);
    } catch (error) {
      console.error(error);
      setMessage('Failed to load expenses');
      setMessageType('error');
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/categories');
      setCategories(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  // Filter and sort expenses
  const filteredExpenses = useMemo(() => {
    let filtered = expenses;

    if (selectedCategory !== 'All') {
      filtered = filtered.filter(e => e.category === selectedCategory);
    }

    if (searchTerm) {
      filtered = filtered.filter(e => 
        e.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (e.notes && e.notes.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (filterDateRange.start) {
      filtered = filtered.filter(e => e.date >= filterDateRange.start);
    }

    if (filterDateRange.end) {
      filtered = filtered.filter(e => e.date <= filterDateRange.end);
    }

    // Sort
    if (sortBy === 'amount-high') {
      filtered.sort((a, b) => b.amount - a.amount);
    } else if (sortBy === 'amount-low') {
      filtered.sort((a, b) => a.amount - b.amount);
    } else if (sortBy === 'date') {
      filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    } else if (sortBy === 'name') {
      filtered.sort((a, b) => a.name.localeCompare(b.name));
    }

    return filtered;
  }, [expenses, selectedCategory, searchTerm, filterDateRange, sortBy]);

  // Statistics
  const stats = useMemo(() => {
    const total = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);
    const byCategory = {};
    filteredExpenses.forEach(e => {
      byCategory[e.category] = (byCategory[e.category] || 0) + e.amount;
    });
    return {
      total,
      count: filteredExpenses.length,
      average: filteredExpenses.length > 0 ? total / filteredExpenses.length : 0,
      byCategory
    };
  }, [filteredExpenses]);

  // Handle form input
  const handleChange = (e) => {
    const { name, value } = e.target;
    setExpenseData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!expenseData.name.trim()) {
      setMessage('Please enter an expense name');
      setMessageType('error');
      return;
    }

    const amount = parseFloat(expenseData.amount);
    if (isNaN(amount) || amount <= 0) {
      setMessage('Please enter a positive amount');
      setMessageType('error');
      return;
    }

    if (!expenseData.category) {
      setMessage('Please select a category');
      setMessageType('error');
      return;
    }

    if (!expenseData.date) {
      setMessage('Please select a date');
      setMessageType('error');
      return;
    }

    try {
      if (editingId) {
        // Update expense
        const response = await axios.put(`http://localhost:5000/api/expenses/${editingId}`, {
          name: expenseData.name,
          amount,
          category: expenseData.category,
          date: expenseData.date,
          notes: expenseData.notes
        });
        setExpenses(prev => prev.map(e => e.id === editingId ? response.data : e));
        setMessage(`✓ Successfully updated ${response.data.name}!`);
        setEditingId(null);
      } else {
        // Create new expense
        const response = await axios.post('http://localhost:5000/api/expenses', {
          name: expenseData.name,
          amount,
          category: expenseData.category,
          date: expenseData.date,
          notes: expenseData.notes
        });
        setExpenses(prev => [response.data, ...prev]);
        setMessage(`✓ Successfully added ${response.data.name}!`);
      }
      
      setMessageType('success');
      setExpenseData({ 
        name: '', 
        amount: '', 
        category: 'Food',
        date: new Date().toISOString().split('T')[0],
        notes: ''
      });
    } catch (error) {
      const errorMsg = error.response?.data?.error || 'Failed to save expense';
      setMessage(`✕ ${errorMsg}`);
      setMessageType('error');
    }
  };

  // Delete expense
  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/expenses/${id}`);
      setExpenses(prev => prev.filter(e => e.id !== id));
      setMessage('✓ Expense deleted successfully!');
      setMessageType('success');
      setDeleteConfirm(null);
    } catch (error) {
      setMessage('✕ Failed to delete expense');
      setMessageType('error');
    }
  };

  // Edit expense
  const handleEdit = (expense) => {
    setExpenseData({
      name: expense.name,
      amount: expense.amount,
      category: expense.category,
      date: expense.date,
      notes: expense.notes || ''
    });
    setEditingId(expense.id);
  };

  // Cancel edit
  const handleCancelEdit = () => {
    setEditingId(null);
    setExpenseData({
      name: '',
      amount: '',
      category: 'Food',
      date: new Date().toISOString().split('T')[0],
      notes: ''
    });
  };

  const totalAmount = stats.total;

  return (
    <div className="expenses-container">
      <div className="expenses-wrapper">
        {/* Header */}
        <div className="expenses-header">
          <h2 className="header-title">💰 Expense Tracker Pro</h2>
          <p className="header-subtitle">Advanced financial management at your fingertips</p>
        </div>

        {/* Alert Message */}
        {message && (
          <div className={`alert alert-${messageType}`}>
            <span className="alert-icon">{messageType === 'success' ? '✓' : '✕'}</span>
            <span className="alert-text">{message}</span>
          </div>
        )}

        {/* Main Content */}
        <div className="content-grid">
          {/* Left Column - Form & Stats */}
          <div className="left-column">
            {/* Form Section */}
            <div className="form-section">
              <h3 className="section-title">{editingId ? '✏️ Edit Expense' : '➕ Add Expense'}</h3>
              <form onSubmit={handleSubmit} className="expense-form">
                <div className="form-group">
                  <label htmlFor="name">Expense Name *</label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={expenseData.name}
                    onChange={handleChange}
                    placeholder="e.g., Groceries, Gas, Dinner"
                    className="form-input"
                  />
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="amount">Amount ($) *</label>
                    <input
                      type="number"
                      id="amount"
                      name="amount"
                      value={expenseData.amount}
                      onChange={handleChange}
                      placeholder="0.00"
                      step="0.01"
                      min="0"
                      className="form-input"
                    />
                  </div>

                  <div className="form-group">
                    <label htmlFor="category">Category *</label>
                    <select
                      id="category"
                      name="category"
                      value={expenseData.category}
                      onChange={handleChange}
                      className="form-input"
                    >
                      {categories.map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="date">Date *</label>
                  <input
                    type="date"
                    id="date"
                    name="date"
                    value={expenseData.date}
                    onChange={handleChange}
                    className="form-input"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="notes">Notes</label>
                  <textarea
                    id="notes"
                    name="notes"
                    value={expenseData.notes}
                    onChange={handleChange}
                    placeholder="Add any notes or details..."
                    className="form-input form-textarea"
                    rows="2"
                  />
                </div>

                <div className="form-buttons">
                  <button type="submit" className="btn btn-primary">
                    {editingId ? '💾 Update' : '➕ Add'} Expense
                  </button>
                  {editingId && (
                    <button
                      type="button"
                      className="btn btn-secondary"
                      onClick={handleCancelEdit}
                    >
                      ✕ Cancel
                    </button>
                  )}
                </div>
              </form>
            </div>

            {/* Quick Stats */}
            <div className="stats-section">
              <h3 className="section-title">📊 Summary</h3>
              <div className="stats-grid">
                <div className="stat-card">
                  <span className="stat-label">Total</span>
                  <span className="stat-value">${totalAmount.toFixed(2)}</span>
                </div>
                <div className="stat-card">
                  <span className="stat-label">Count</span>
                  <span className="stat-value">{stats.count}</span>
                </div>
                <div className="stat-card">
                  <span className="stat-label">Average</span>
                  <span className="stat-value">${stats.average.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Expenses List */}
          <div className="right-column">
            {/* Filter & Search */}
            <div className="filter-section">
              <h3 className="section-title">🔍 Filter & Search</h3>
              
              <div className="filter-controls">
                <input
                  type="text"
                  placeholder="Search expenses..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="filter-input"
                />

                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="filter-input"
                >
                  <option>All Categories</option>
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>

                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="filter-input"
                >
                  <option value="date">Sort: Latest</option>
                  <option value="amount-high">Sort: High to Low</option>
                  <option value="amount-low">Sort: Low to High</option>
                  <option value="name">Sort: A to Z</option>
                </select>

                <button
                  className={`filter-btn ${showStats ? 'active' : ''}`}
                  onClick={() => setShowStats(!showStats)}
                >
                  📈 Breakdown
                </button>
              </div>

              {/* Date Range Filter */}
              <div className="date-filter">
                <input
                  type="date"
                  value={filterDateRange.start}
                  onChange={(e) => setFilterDateRange(prev => ({ ...prev, start: e.target.value }))}
                  className="filter-input"
                  placeholder="From"
                />
                <input
                  type="date"
                  value={filterDateRange.end}
                  onChange={(e) => setFilterDateRange(prev => ({ ...prev, end: e.target.value }))}
                  className="filter-input"
                  placeholder="To"
                />
              </div>
            </div>

            {/* Category Breakdown */}
            {showStats && Object.keys(stats.byCategory).length > 0 && (
              <div className="breakdown-section">
                <h3 className="section-title">📈 Breakdown by Category</h3>
                <div className="breakdown-list">
                  {Object.entries(stats.byCategory).map(([category, amount]) => (
                    <div key={category} className="breakdown-item">
                      <div className="breakdown-label">
                        <span
                          className="category-dot"
                          style={{ backgroundColor: CATEGORY_COLORS[category] || '#6b7280' }}
                        ></span>
                        <span>{category}</span>
                      </div>
                      <div className="breakdown-bar">
                        <div
                          className="breakdown-fill"
                          style={{
                            width: `${(amount / stats.total) * 100}%`,
                            backgroundColor: CATEGORY_COLORS[category] || '#6b7280'
                          }}
                        ></div>
                      </div>
                      <span className="breakdown-amount">${amount.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Expenses List */}
            <div className="list-section">
              <div className="list-header">
                <h3 className="section-title">💸 Expenses</h3>
                <span className="expense-badge">{filteredExpenses.length}</span>
              </div>

              {loading ? (
                <div className="loading-state">
                  <div className="spinner"></div>
                  <p>Loading expenses...</p>
                </div>
              ) : filteredExpenses.length === 0 ? (
                <div className="empty-state">
                  <div className="empty-icon">📊</div>
                  <p>{searchTerm || selectedCategory !== 'All' ? 'No matching expenses found' : 'No expenses yet. Start adding some!'}</p>
                </div>
              ) : (
                <div className="expenses-list">
                  {filteredExpenses.map(expense => (
                    <div key={expense.id} className="expense-card">
                      <div className="expense-header">
                        <div className="expense-info">
                          <h4 className="expense-name">{expense.name}</h4>
                          <span
                            className="category-badge"
                            style={{ backgroundColor: CATEGORY_COLORS[expense.category] || '#6b7280' }}
                          >
                            {expense.category}
                          </span>
                        </div>
                        <div className="expense-amount">${expense.amount.toFixed(2)}</div>
                      </div>
                      
                      {expense.notes && (
                        <p className="expense-notes">📝 {expense.notes}</p>
                      )}
                      
                      <div className="expense-footer">
                        <span className="expense-date">📅 {new Date(expense.date).toLocaleDateString()}</span>
                        <div className="expense-actions">
                          <button
                            className="btn-action btn-edit"
                            onClick={() => handleEdit(expense)}
                            title="Edit"
                          >
                            ✏️
                          </button>
                          <button
                            className="btn-action btn-delete"
                            onClick={() => setDeleteConfirm(expense.id)}
                            title="Delete"
                          >
                            🗑️
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirm && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h3>⚠️ Confirm Delete</h3>
            <p>Are you sure you want to delete this expense? This action cannot be undone.</p>
            <div className="modal-buttons">
              <button className="btn btn-primary" onClick={() => handleDelete(deleteConfirm)}>
                Yes, Delete
              </button>
              <button className="btn btn-secondary" onClick={() => setDeleteConfirm(null)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Expenses;
