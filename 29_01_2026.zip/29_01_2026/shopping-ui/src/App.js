import { useState } from "react";
import ProductCard from "./components/ProductCard";
import "./index.css";

function App() {
  const [cartCount, setCartCount] = useState(0);

  const products = [
    {
      id: 1,
      name: "Laptop",
      price: 55000,
      image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
      rating: 4.5
    },
    {
      id: 2,
      name: "Headphones",
      price: 2000,
      image: "https://images.unsplash.com/photo-1511367461989-f85a21fda167",
      rating: 4.2
    },
    {
      id: 3,
      name: "Smart Watch",
      price: 3000,
      image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30",
      rating: 4.6
    },
    {
      id: 4,
      name: "Keyboard",
      price: 1500,
      image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3",
      rating: 4.1
    }
  ];

  return (
    <>
      <header>
        <h1>Online Shopping Store</h1>
        <p>Cart Items: {cartCount}</p>
      </header>

      <div className="product-grid">
        {products.map(product => (
          <ProductCard
            key={product.id}
            name={product.name}
            price={product.price}
            image={product.image}
            rating={product.rating}
            onAdd={() => setCartCount(cartCount + 1)}
          />
        ))}
      </div>
    </>
  );
}

export default App;
