import React, { useState, useEffect } from 'react';
import './App.css';
import Dashboard from './components/Dashboard';
import ExpenseForm from './components/ExpenseForm';
import IncomeForm from './components/IncomeForm';
import ExpenseList from './components/ExpenseList';
import IncomeList from './components/IncomeList';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

function App() {
  const [dashboard, setDashboard] = useState({
    totalIncome: 0,
    totalExpenses: 0,
    balance: 0,
  });
  const [expenses, setExpenses] = useState([]);
  const [income, setIncome] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');

  // Fetch dashboard data
  const fetchDashboard = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/dashboard`);
      if (response.ok) {
        const data = await response.json();
        setDashboard(data);
      }
    } catch (err) {
      setError('Failed to fetch dashboard data');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch expenses
  const fetchExpenses = async () => {
    try {
      const response = await fetch(`${API_URL}/expenses`);
      if (response.ok) {
        const data = await response.json();
        setExpenses(data.expenses || []);
      }
    } catch (err) {
      setError('Failed to fetch expenses');
      console.error(err);
    }
  };

  // Fetch income
  const fetchIncome = async () => {
    try {
      const response = await fetch(`${API_URL}/income`);
      if (response.ok) {
        const data = await response.json();
        setIncome(data.income || []);
      }
    } catch (err) {
      setError('Failed to fetch income');
      console.error(err);
    }
  };

  // Refresh all data
  const refreshAllData = () => {
    fetchDashboard();
    fetchExpenses();
    fetchIncome();
  };

  // Initial load
  useEffect(() => {
    refreshAllData();
  }, []);

  // Add expense
  const handleAddExpense = async (expenseData) => {
    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/expenses`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(expenseData),
      });

      if (response.ok) {
        setSuccessMessage('Expense added successfully!');
        setTimeout(() => setSuccessMessage(''), 3000);
        refreshAllData();
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Failed to add expense');
      }
    } catch (err) {
      setError('Failed to add expense');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Add income
  const handleAddIncome = async (incomeData) => {
    try {
      setLoading(true);
      const response = await fetch(`${API_URL}/income`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(incomeData),
      });

      if (response.ok) {
        setSuccessMessage('Income added successfully!');
        setTimeout(() => setSuccessMessage(''), 3000);
        refreshAllData();
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Failed to add income');
      }
    } catch (err) {
      setError('Failed to add income');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Reset data (for testing)
  const handleReset = async () => {
    if (window.confirm('Are you sure you want to reset all data?')) {
      try {
        await fetch(`${API_URL}/reset`, { method: 'POST' });
        setExpenses([]);
        setIncome([]);
        setDashboard({
          totalIncome: 0,
          totalExpenses: 0,
          balance: 0,
        });
        setSuccessMessage('All data has been reset');
        setTimeout(() => setSuccessMessage(''), 3000);
      } catch (err) {
        setError('Failed to reset data');
        console.error(err);
      }
    }
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>💰 Personal Finance Tracker</h1>
        <p>Manage your income and expenses efficiently</p>
      </header>

      <main className="app-main">
        {/* Error Message */}
        {error && (
          <div className="alert alert-error" role="alert">
            {error}
            <button
              className="alert-close"
              onClick={() => setError(null)}
              aria-label="Close error message"
            >
              ×
            </button>
          </div>
        )}

        {/* Success Message */}
        {successMessage && (
          <div className="alert alert-success" role="alert">
            {successMessage}
          </div>
        )}

        {/* Dashboard */}
        <Dashboard
          totalIncome={dashboard.totalIncome}
          totalExpenses={dashboard.totalExpenses}
          balance={dashboard.balance}
          loading={loading}
        />

        {/* Forms Section */}
        <section className="forms-section">
          <div className="form-container">
            <IncomeForm onAddIncome={handleAddIncome} loading={loading} />
          </div>
          <div className="form-container">
            <ExpenseForm onAddExpense={handleAddExpense} loading={loading} />
          </div>
        </section>

        {/* Lists Section */}
        <section className="lists-section">
          <div className="list-container">
            <IncomeList incomeItems={income} />
          </div>
          <div className="list-container">
            <ExpenseList expenses={expenses} />
          </div>
        </section>

        {/* Reset Button (for testing) */}
        <div className="controls">
          <button
            className="btn btn-reset"
            onClick={handleReset}
            title="Reset all data for testing purposes"
          >
            🔄 Reset All Data
          </button>
        </div>
      </main>

      <footer className="app-footer">
        <p>
          Finance CI Integration • Powered by React + Express • © 2026
        </p>
      </footer>
    </div>
  );
}

export default App;
