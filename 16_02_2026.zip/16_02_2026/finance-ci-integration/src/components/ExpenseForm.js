import React, { useState } from 'react';
import './Form.css';

function ExpenseForm({ onAddExpense, loading }) {
  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    category: 'General',
  });

  const categories = ['General', 'Housing', 'Food', 'Transport', 'Utilities', 'Entertainment', 'Healthcare', 'Other'];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === 'amount' ? parseFloat(value) || '' : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.description && formData.amount > 0) {
      onAddExpense(formData);
      setFormData({
        description: '',
        amount: '',
        category: 'General',
      });
    }
  };

  return (
    <form
      className="form expense-form"
      onSubmit={handleSubmit}
      data-testid="expense-form"
    >
      <h3>➕ Add New Expense</h3>

      <div className="form-group">
        <label htmlFor="expense-description">
          Description <span className="required">*</span>
        </label>
        <input
          id="expense-description"
          type="text"
          name="description"
          value={formData.description}
          onChange={handleChange}
          placeholder="e.g., Rent, Groceries, Gas"
          required
          data-testid="expense-description-input"
        />
      </div>

      <div className="form-group">
        <label htmlFor="expense-amount">
          Amount (USD) <span className="required">*</span>
        </label>
        <input
          id="expense-amount"
          type="number"
          name="amount"
          value={formData.amount}
          onChange={handleChange}
          placeholder="0.00"
          step="0.01"
          min="0"
          required
          data-testid="expense-amount-input"
        />
      </div>

      <div className="form-group">
        <label htmlFor="expense-category">Category</label>
        <select
          id="expense-category"
          name="category"
          value={formData.category}
          onChange={handleChange}
          data-testid="expense-category-select"
        >
          {categories.map((cat) => (
            <option key={cat} value={cat}>
              {cat}
            </option>
          ))}
        </select>
      </div>

      <button
        type="submit"
        className="btn btn-primary"
        disabled={loading}
        data-testid="add-expense-btn"
      >
        {loading ? 'Adding...' : 'Add Expense'}
      </button>
    </form>
  );
}

export default ExpenseForm;
