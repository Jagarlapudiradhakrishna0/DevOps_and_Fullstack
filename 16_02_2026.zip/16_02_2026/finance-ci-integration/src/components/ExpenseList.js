import React from 'react';
import './List.css';

function ExpenseList({ expenses }) {
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <section className="list-section expense-list" data-testid="expense-list">
      <h3>📊 Recent Expenses</h3>

      {expenses.length === 0 ? (
        <p className="empty-message">No expenses recorded yet</p>
      ) : (
        <div className="list-items">
          {expenses.map((expense) => (
            <div
              key={expense.id}
              className="list-item expense-item"
              data-testid={`expense-item-${expense.id}`}
            >
              <div className="item-info">
                <h4 className="item-description" data-testid={`expense-desc-${expense.id}`}>
                  {expense.description}
                </h4>
                <div className="item-meta">
                  <span className="category-badge">{expense.category}</span>
                  <span className="timestamp">{formatDate(expense.createdAt)}</span>
                </div>
              </div>
              <div
                className="item-amount expense-amount"
                data-testid={`expense-amount-${expense.id}`}
              >
                -{formatCurrency(expense.amount)}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="list-footer">
        <p>Total expenses: {expenses.length}</p>
      </div>
    </section>
  );
}

export default ExpenseList;
