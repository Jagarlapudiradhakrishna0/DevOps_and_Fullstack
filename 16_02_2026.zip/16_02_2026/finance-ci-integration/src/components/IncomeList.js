import React from 'react';
import './List.css';

function IncomeList({ incomeItems }) {
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <section className="list-section income-list" data-testid="income-list">
      <h3>💲 Recent Income</h3>

      {incomeItems.length === 0 ? (
        <p className="empty-message">No income recorded yet</p>
      ) : (
        <div className="list-items">
          {incomeItems.map((income) => (
            <div
              key={income.id}
              className="list-item income-item"
              data-testid={`income-item-${income.id}`}
            >
              <div className="item-info">
                <h4 className="item-description" data-testid={`income-desc-${income.id}`}>
                  {income.description}
                </h4>
                <div className="item-meta">
                  <span className="source-badge">{income.source}</span>
                  <span className="timestamp">{formatDate(income.createdAt)}</span>
                </div>
              </div>
              <div
                className="item-amount income-amount"
                data-testid={`income-amount-${income.id}`}
              >
                +{formatCurrency(income.amount)}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="list-footer">
        <p>Total income records: {incomeItems.length}</p>
      </div>
    </section>
  );
}

export default IncomeList;
