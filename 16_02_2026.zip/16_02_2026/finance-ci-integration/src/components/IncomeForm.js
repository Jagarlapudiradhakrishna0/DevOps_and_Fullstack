import React, { useState } from 'react';
import './Form.css';

function IncomeForm({ onAddIncome, loading }) {
  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    source: 'Other',
  });

  const sources = ['Other', 'Salary', 'Freelance', 'Investment', 'Bonus', 'Gift', 'Business'];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === 'amount' ? parseFloat(value) || '' : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.description && formData.amount > 0) {
      onAddIncome(formData);
      setFormData({
        description: '',
        amount: '',
        source: 'Other',
      });
    }
  };

  return (
    <form
      className="form income-form"
      onSubmit={handleSubmit}
      data-testid="income-form"
    >
      <h3>➕ Add New Income</h3>

      <div className="form-group">
        <label htmlFor="income-description">
          Description <span className="required">*</span>
        </label>
        <input
          id="income-description"
          type="text"
          name="description"
          value={formData.description}
          onChange={handleChange}
          placeholder="e.g., Monthly Salary, Freelance Project"
          required
          data-testid="income-description-input"
        />
      </div>

      <div className="form-group">
        <label htmlFor="income-amount">
          Amount (USD) <span className="required">*</span>
        </label>
        <input
          id="income-amount"
          type="number"
          name="amount"
          value={formData.amount}
          onChange={handleChange}
          placeholder="0.00"
          step="0.01"
          min="0"
          required
          data-testid="income-amount-input"
        />
      </div>

      <div className="form-group">
        <label htmlFor="income-source">Source</label>
        <select
          id="income-source"
          name="source"
          value={formData.source}
          onChange={handleChange}
          data-testid="income-source-select"
        >
          {sources.map((src) => (
            <option key={src} value={src}>
              {src}
            </option>
          ))}
        </select>
      </div>

      <button
        type="submit"
        className="btn btn-primary"
        disabled={loading}
        data-testid="add-income-btn"
      >
        {loading ? 'Adding...' : 'Add Income'}
      </button>
    </form>
  );
}

export default IncomeForm;
