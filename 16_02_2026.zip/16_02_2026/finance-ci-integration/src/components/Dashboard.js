import React from 'react';
import './Dashboard.css';

function Dashboard({ totalIncome, totalExpenses, balance, loading }) {
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  return (
    <section className="dashboard" data-testid="dashboard">
      <h2>💼 Financial Dashboard</h2>

      <div className="dashboard-grid">
        {/* Income Card */}
        <div className="dashboard-card income-card" data-testid="income-card">
          <div className="card-header">
            <h3>Total Income</h3>
            <span className="card-icon">📈</span>
          </div>
          <div className="card-value" data-testid="total-income">
            {loading ? '...' : formatCurrency(totalIncome)}
          </div>
          <p className="card-description">Cumulative earnings</p>
        </div>

        {/* Expenses Card */}
        <div className="dashboard-card expense-card" data-testid="expense-card">
          <div className="card-header">
            <h3>Total Expenses</h3>
            <span className="card-icon">📉</span>
          </div>
          <div className="card-value" data-testid="total-expenses">
            {loading ? '...' : formatCurrency(totalExpenses)}
          </div>
          <p className="card-description">Cumulative spending</p>
        </div>

        {/* Balance Card */}
        <div
          className={`dashboard-card balance-card ${
            balance >= 0 ? 'positive' : 'negative'
          }`}
          data-testid="balance-card"
        >
          <div className="card-header">
            <h3>Balance</h3>
            <span className="card-icon">{balance >= 0 ? '✅' : '⚠️'}</span>
          </div>
          <div className="card-value" data-testid="balance">
            {loading ? '...' : formatCurrency(balance)}
          </div>
          <p className="card-description">
            {balance >= 0 ? 'You are in the positive' : 'You are in the negative'}
          </p>
        </div>
      </div>
    </section>
  );
}

export default Dashboard;
