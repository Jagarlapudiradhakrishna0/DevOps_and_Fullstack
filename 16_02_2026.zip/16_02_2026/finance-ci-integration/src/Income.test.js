import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';

// Income component
function Income() {
  return <h1>Income</h1>;
}

describe('Income Component', () => {
  it('should render Income component with title', () => {
    render(<Income />);
    const heading = screen.getByRole('heading', { level: 1 });
    expect(heading).toBeInTheDocument();
  });

  it('should check that text "Income" exists', () => {
    render(<Income />);
    const incomeText = screen.getByText('Income');
    expect(incomeText).toBeInTheDocument();
  });

  it('should render h1 element with Income text', () => {
    render(<Income />);
    const heading = screen.getByText('Income');
    expect(heading.tagName).toBe('H1');
  });
});
