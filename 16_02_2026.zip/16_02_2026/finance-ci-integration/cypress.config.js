module.exports = {
  e2e: {
    // Base URL for frontend
    baseUrl: 'http://localhost:3000',
    // API URL for backend
    apiUrl: 'http://localhost:5000',
    // Viewport configuration
    viewportWidth: 1280,
    viewportHeight: 720,
    // Test execution timeouts
    defaultCommandTimeout: 10000,
    requestTimeout: 10000,
    responseTimeout: 10000,
    // Screenshots and video configuration
    screenshotOnRunFailure: true,
    screenshotOnRun: false,
    video: true,
    videoCompression: 32,
    videosFolder: 'cypress/videos',
    screenshotsFolder: 'cypress/screenshots',
    // Number of test threads
    numTestsKeptInMemory: 0,
    // Retry configuration
    retries: 0,
    // Setup and teardown files
    setupNodeEvents(on, config) {
      // Implement node event listeners here
      // Example: logging events
      on('task', {
        log(message) {
          console.log(message);
          return null;
        },
      });
    },
  },
};
