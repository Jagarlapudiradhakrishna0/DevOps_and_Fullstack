describe('Finance Application E2E Tests', () => {
  const API_URL = 'http://localhost:5000';
  const APP_URL = 'http://localhost:3000';

  // Reset backend data before each test
  beforeEach(() => {
    // Reset the backend data via API
    cy.request('POST', `${API_URL}/api/reset`).then((response) => {
      expect(response.status).to.equal(200);
    });

    // Visit the application
    cy.visit(APP_URL);
  });

  describe('Dashboard Loading', () => {
    it('should load dashboard successfully', () => {
      cy.visit(APP_URL);
      cy.window().should('exist');
    });

    it('should verify backend health check', () => {
      cy.request('GET', `${API_URL}/api/health`).then((response) => {
        expect(response.status).to.equal(200);
        expect(response.body.status).to.equal('OK');
      });
    });

    it('should load initial dashboard state', () => {
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.status).to.equal(200);
        expect(response.body.totalIncome).to.equal(0);
        expect(response.body.totalExpenses).to.equal(0);
        expect(response.body.balance).to.equal(0);
      });
    });
  });

  describe('Expense Creation - End-to-End', () => {
    it('should create expense via API and update dashboard', () => {
      // Create first expense
      cy.request('POST', `${API_URL}/api/expenses`, {
        description: 'Rent Payment',
        amount: 1500,
        category: 'Housing',
      }).then((response) => {
        expect(response.status).to.equal(201);
        expect(response.body.expense.description).to.equal('Rent Payment');
        expect(response.body.expense.amount).to.equal(1500);
      });

      // Create second expense
      cy.request('POST', `${API_URL}/api/expenses`, {
        description: 'Groceries',
        amount: 250,
        category: 'Food',
      }).then((response) => {
        expect(response.status).to.equal(201);
        expect(response.body.expense.description).to.equal('Groceries');
        expect(response.body.expense.amount).to.equal(250);
      });

      // Verify expenses were added
      cy.request('GET', `${API_URL}/api/expenses`).then((response) => {
        expect(response.status).to.equal(200);
        expect(response.body.expenses).to.have.length(2);
      });

      // Verify dashboard updated with expenses
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.status).to.equal(200);
        expect(response.body.totalExpenses).to.equal(1750);
      });
    });

    it('should create multiple expenses and verify total', () => {
      const expenses = [
        { description: 'Rent', amount: 1000, category: 'Housing' },
        { description: 'Utilities', amount: 150, category: 'Utilities' },
        { description: 'Food', amount: 300, category: 'Food' },
        { description: 'Transport', amount: 100, category: 'Transport' },
      ];

      let totalExpected = 0;

      // Create all expenses
      expenses.forEach((expense) => {
        cy.request('POST', `${API_URL}/api/expenses`, expense).then((response) => {
          expect(response.status).to.equal(201);
          totalExpected += expense.amount;
        });
      });

      // Verify dashboard total
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.status).to.equal(200);
        expect(response.body.totalExpenses).to.equal(totalExpected);
      });
    });

    it('should reject invalid expense', () => {
      cy.request({
        method: 'POST',
        url: `${API_URL}/api/expenses`,
        body: { description: 'Invalid', amount: -100, category: 'Test' },
        failOnStatusCode: false,
      }).then((response) => {
        expect(response.status).to.equal(400);
        expect(response.body.error).to.exist;
      });
    });
  });

  describe('Income Creation & Dashboard Update', () => {
    it('should create income and update dashboard balance', () => {
      // Add income
      cy.request('POST', `${API_URL}/api/income`, {
        description: 'Monthly Salary',
        amount: 5000,
        source: 'Employment',
      }).then((response) => {
        expect(response.status).to.equal(201);
        expect(response.body.income.description).to.equal('Monthly Salary');
      });

      // Verify dashboard shows income
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.status).to.equal(200);
        expect(response.body.totalIncome).to.equal(5000);
        expect(response.body.balance).to.equal(5000);
      });
    });

    it('should verify balance calculation with income and expenses', () => {
      // Add income
      cy.request('POST', `${API_URL}/api/income`, {
        description: 'Salary',
        amount: 5000,
        source: 'Employment',
      }).then((response) => {
        expect(response.status).to.equal(201);
      });

      // Add expenses
      cy.request('POST', `${API_URL}/api/expenses`, {
        description: 'Rent',
        amount: 1500,
        category: 'Housing',
      }).then((response) => {
        expect(response.status).to.equal(201);
      });

      cy.request('POST', `${API_URL}/api/expenses`, {
        description: 'Utilities',
        amount: 300,
        category: 'Utilities',
      }).then((response) => {
        expect(response.status).to.equal(201);
      });

      // Verify dashboard calculation
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.status).to.equal(200);
        expect(response.body.totalIncome).to.equal(5000);
        expect(response.body.totalExpenses).to.equal(1800);
        expect(response.body.balance).to.equal(3200);
      });
    });

    it('should create multiple income sources', () => {
      const incomes = [
        { description: 'Salary', amount: 4000, source: 'Employment' },
        { description: 'Freelance', amount: 1500, source: 'Freelance' },
        { description: 'Bonus', amount: 500, source: 'Employment' },
      ];

      let totalIncome = 0;

      // Create all income items
      incomes.forEach((income) => {
        cy.request('POST', `${API_URL}/api/income`, income).then((response) => {
          expect(response.status).to.equal(201);
          totalIncome += income.amount;
        });
      });

      // Verify dashboard shows total income
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.status).to.equal(200);
        expect(response.body.totalIncome).to.equal(totalIncome);
      });
    });

    it('should add income and then add expense, verify balance updates', () => {
      // Step 1: Add income of 3000
      cy.request('POST', `${API_URL}/api/income`, {
        description: 'Income',
        amount: 3000,
        source: 'Work',
      }).then((response) => {
        expect(response.status).to.equal(201);
      });

      // Step 2: Verify balance is 3000
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.body.balance).to.equal(3000);
      });

      // Step 3: Add expense of 500
      cy.request('POST', `${API_URL}/api/expenses`, {
        description: 'Expense',
        amount: 500,
        category: 'General',
      }).then((response) => {
        expect(response.status).to.equal(201);
      });

      // Step 4: Verify balance is now 2500
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.body.totalIncome).to.equal(3000);
        expect(response.body.totalExpenses).to.equal(500);
        expect(response.body.balance).to.equal(2500);
      });
    });

    it('should reject invalid income', () => {
      cy.request({
        method: 'POST',
        url: `${API_URL}/api/income`,
        body: { description: 'Invalid', amount: 0, source: 'Test' },
        failOnStatusCode: false,
      }).then((response) => {
        expect(response.status).to.equal(400);
        expect(response.body.error).to.exist;
      });
    });
  });

  describe('Complex Scenarios', () => {
    it('should handle complex financial workflow', () => {
      // Initial state: balance 0
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.body.balance).to.equal(0);
      });

      // Add first income
      cy.request('POST', `${API_URL}/api/income`, {
        description: 'Initial Salary',
        amount: 10000,
        source: 'Employment',
      });

      // After first income: balance 10000
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.body.totalIncome).to.equal(10000);
        expect(response.body.balance).to.equal(10000);
      });

      // Add multiple expenses
      cy.request('POST', `${API_URL}/api/expenses`, {
        description: 'Housing',
        amount: 2000,
        category: 'Housing',
      });

      cy.request('POST', `${API_URL}/api/expenses`, {
        description: 'Food',
        amount: 500,
        category: 'Food',
      });

      cy.request('POST', `${API_URL}/api/expenses`, {
        description: 'Entertainment',
        amount: 300,
        category: 'Entertainment',
      });

      // After expenses: balance should be 7200
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.body.totalExpenses).to.equal(2800);
        expect(response.body.balance).to.equal(7200);
      });

      // Add bonus income
      cy.request('POST', `${API_URL}/api/income`, {
        description: 'Performance Bonus',
        amount: 2000,
        source: 'Employment',
      });

      // After bonus: balance should be 9200
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.body.totalIncome).to.equal(12000);
        expect(response.body.balance).to.equal(9200);
      });
    });

    it('should verify data persistence across multiple operations', () => {
      const operations = [
        {
          type: 'income',
          data: { description: 'Salary', amount: 5000, source: 'Work' },
        },
        {
          type: 'expense',
          data: { description: 'Rent', amount: 1500, category: 'Housing' },
        },
        {
          type: 'income',
          data: { description: 'Freelance', amount: 500, source: 'Side Work' },
        },
        {
          type: 'expense',
          data: { description: 'Food', amount: 300, category: 'Food' },
        },
      ];

      let totalIncomeExpected = 0;
      let totalExpensesExpected = 0;

      // Execute all operations
      operations.forEach((op) => {
        const endpoint =
          op.type === 'income'
            ? `${API_URL}/api/income`
            : `${API_URL}/api/expenses`;

        cy.request('POST', endpoint, op.data).then((response) => {
          expect(response.status).to.equal(201);

          if (op.type === 'income') {
            totalIncomeExpected += op.data.amount;
          } else {
            totalExpensesExpected += op.data.amount;
          }
        });
      });

      // Verify final state
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.body.totalIncome).to.equal(totalIncomeExpected);
        expect(response.body.totalExpenses).to.equal(totalExpensesExpected);
        expect(response.body.balance).to.equal(
          totalIncomeExpected - totalExpensesExpected
        );
      });
    });
  });

  describe('Data Reset', () => {
    it('should reset all data successfully', () => {
      // Add data
      cy.request('POST', `${API_URL}/api/income`, {
        description: 'Income',
        amount: 5000,
        source: 'Work',
      });

      cy.request('POST', `${API_URL}/api/expenses`, {
        description: 'Expense',
        amount: 1000,
        category: 'General',
      });

      // Verify data exists
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.body.totalIncome).to.equal(5000);
        expect(response.body.totalExpenses).to.equal(1000);
      });

      // Reset
      cy.request('POST', `${API_URL}/api/reset`).then((response) => {
        expect(response.status).to.equal(200);
      });

      // Verify data is cleared
      cy.request('GET', `${API_URL}/api/dashboard`).then((response) => {
        expect(response.body.totalIncome).to.equal(0);
        expect(response.body.totalExpenses).to.equal(0);
        expect(response.body.balance).to.equal(0);
      });
    });
  });
});
