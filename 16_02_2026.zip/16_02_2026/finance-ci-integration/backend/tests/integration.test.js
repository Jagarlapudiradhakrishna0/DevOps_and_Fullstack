const request = require('supertest');
const app = require('../app');

describe('Finance API Integration Tests', () => {
  // Reset data before each test
  beforeEach(async () => {
    await request(app).post('/api/reset').expect(200);
  });

  describe('GET /api/health', () => {
    it('should return health status', async () => {
      const response = await request(app)
        .get('/api/health')
        .expect(200);

      expect(response.body.status).toBe('OK');
      expect(response.body.message).toBe('Backend is running');
    });
  });

  describe('Dashboard API - GET /api/dashboard', () => {
    it('should return initial dashboard with zeros', async () => {
      const response = await request(app)
        .get('/api/dashboard')
        .expect(200);

      expect(response.body.totalIncome).toBe(0);
      expect(response.body.totalExpenses).toBe(0);
      expect(response.body.balance).toBe(0);
      expect(response.body.timestamp).toBeDefined();
    });

    it('should calculate correct balance after adding income and expenses', async () => {
      // Add income
      await request(app)
        .post('/api/income')
        .send({ description: 'Salary', amount: 5000, source: 'Employment' })
        .expect(201);

      // Add expense
      await request(app)
        .post('/api/expenses')
        .send({ description: 'Rent', amount: 1000, category: 'Housing' })
        .expect(201);

      // Check dashboard
      const response = await request(app)
        .get('/api/dashboard')
        .expect(200);

      expect(response.body.totalIncome).toBe(5000);
      expect(response.body.totalExpenses).toBe(1000);
      expect(response.body.balance).toBe(4000);
    });

    it('should correctly sum multiple income entries', async () => {
      // Add multiple income items
      await request(app)
        .post('/api/income')
        .send({ description: 'Salary', amount: 3000, source: 'Employment' })
        .expect(201);

      await request(app)
        .post('/api/income')
        .send({ description: 'Freelance', amount: 1000, source: 'Freelance' })
        .expect(201);

      // Check dashboard
      const response = await request(app)
        .get('/api/dashboard')
        .expect(200);

      expect(response.body.totalIncome).toBe(4000);
    });

    it('should correctly sum multiple expense entries', async () => {
      // Add multiple expenses
      await request(app)
        .post('/api/expenses')
        .send({ description: 'Rent', amount: 1000, category: 'Housing' })
        .expect(201);

      await request(app)
        .post('/api/expenses')
        .send({ description: 'Groceries', amount: 200, category: 'Food' })
        .expect(201);

      await request(app)
        .post('/api/expenses')
        .send({ description: 'Utilities', amount: 150, category: 'Utilities' })
        .expect(201);

      // Check dashboard
      const response = await request(app)
        .get('/api/dashboard')
        .expect(200);

      expect(response.body.totalExpenses).toBe(1350);
    });
  });

  describe('Expenses API - GET /api/expenses', () => {
    it('should return empty list initially', async () => {
      const response = await request(app)
        .get('/api/expenses')
        .expect(200);

      expect(response.body.expenses).toEqual([]);
      expect(response.body.count).toBe(0);
    });

    it('should return all added expenses', async () => {
      // Add two expenses
      await request(app)
        .post('/api/expenses')
        .send({ description: 'Rent', amount: 1000, category: 'Housing' })
        .expect(201);

      await request(app)
        .post('/api/expenses')
        .send({ description: 'Groceries', amount: 200, category: 'Food' })
        .expect(201);

      // Get all expenses
      const response = await request(app)
        .get('/api/expenses')
        .expect(200);

      expect(response.body.count).toBe(2);
      expect(response.body.expenses.length).toBe(2);
      expect(response.body.expenses[0].description).toBe('Rent');
      expect(response.body.expenses[1].description).toBe('Groceries');
    });
  });

  describe('Expenses API - POST /api/expenses', () => {
    it('should add a new expense successfully', async () => {
      const response = await request(app)
        .post('/api/expenses')
        .send({ description: 'Rent', amount: 1000, category: 'Housing' })
        .expect(201);

      expect(response.body.message).toBe('Expense added successfully');
      expect(response.body.expense.description).toBe('Rent');
      expect(response.body.expense.amount).toBe(1000);
      expect(response.body.expense.category).toBe('Housing');
      expect(response.body.expense.id).toBeDefined();
      expect(response.body.expense.createdAt).toBeDefined();
    });

    it('should reject expense without description', async () => {
      const response = await request(app)
        .post('/api/expenses')
        .send({ amount: 1000, category: 'Housing' })
        .expect(400);

      expect(response.body.error).toBeDefined();
    });

    it('should reject expense with zero amount', async () => {
      const response = await request(app)
        .post('/api/expenses')
        .send({ description: 'Rent', amount: 0, category: 'Housing' })
        .expect(400);

      expect(response.body.error).toBeDefined();
    });

    it('should reject expense with negative amount', async () => {
      const response = await request(app)
        .post('/api/expenses')
        .send({ description: 'Rent', amount: -100, category: 'Housing' })
        .expect(400);

      expect(response.body.error).toBeDefined();
    });

    it('should use default category if not provided', async () => {
      const response = await request(app)
        .post('/api/expenses')
        .send({ description: 'Random expense', amount: 50 })
        .expect(201);

      expect(response.body.expense.category).toBe('General');
    });
  });

  describe('Expenses GET + POST Consistency', () => {
    it('should ensure posted expenses match retrieved expenses', async () => {
      // Post expense
      const postResponse = await request(app)
        .post('/api/expenses')
        .send({ description: 'Test', amount: 123.45, category: 'Test' })
        .expect(201);

      const postedExpense = postResponse.body.expense;

      // Get expenses
      const getResponse = await request(app)
        .get('/api/expenses')
        .expect(200);

      expect(getResponse.body.expenses).toContainEqual(postedExpense);
    });
  });

  describe('Income API - GET /api/income', () => {
    it('should return empty list initially', async () => {
      const response = await request(app)
        .get('/api/income')
        .expect(200);

      expect(response.body.income).toEqual([]);
      expect(response.body.count).toBe(0);
    });

    it('should return all added income items', async () => {
      // Add two income items
      await request(app)
        .post('/api/income')
        .send({ description: 'Salary', amount: 5000, source: 'Employment' })
        .expect(201);

      await request(app)
        .post('/api/income')
        .send({ description: 'Bonus', amount: 1000, source: 'Employment' })
        .expect(201);

      // Get all income
      const response = await request(app)
        .get('/api/income')
        .expect(200);

      expect(response.body.count).toBe(2);
      expect(response.body.income.length).toBe(2);
      expect(response.body.income[0].description).toBe('Salary');
      expect(response.body.income[1].description).toBe('Bonus');
    });
  });

  describe('Income API - POST /api/income', () => {
    it('should add a new income item successfully', async () => {
      const response = await request(app)
        .post('/api/income')
        .send({ description: 'Salary', amount: 5000, source: 'Employment' })
        .expect(201);

      expect(response.body.message).toBe('Income added successfully');
      expect(response.body.income.description).toBe('Salary');
      expect(response.body.income.amount).toBe(5000);
      expect(response.body.income.source).toBe('Employment');
      expect(response.body.income.id).toBeDefined();
      expect(response.body.income.createdAt).toBeDefined();
    });

    it('should reject income without description', async () => {
      const response = await request(app)
        .post('/api/income')
        .send({ amount: 5000, source: 'Employment' })
        .expect(400);

      expect(response.body.error).toBeDefined();
    });

    it('should reject income with zero amount', async () => {
      const response = await request(app)
        .post('/api/income')
        .send({ description: 'Salary', amount: 0, source: 'Employment' })
        .expect(400);

      expect(response.body.error).toBeDefined();
    });

    it('should reject income with negative amount', async () => {
      const response = await request(app)
        .post('/api/income')
        .send({ description: 'Salary', amount: -5000, source: 'Employment' })
        .expect(400);

      expect(response.body.error).toBeDefined();
    });

    it('should use default source if not provided', async () => {
      const response = await request(app)
        .post('/api/income')
        .send({ description: 'Found money', amount: 50 })
        .expect(201);

      expect(response.body.income.source).toBe('Other');
    });
  });

  describe('Income GET + POST Consistency', () => {
    it('should ensure posted income matches retrieved income', async () => {
      // Post income
      const postResponse = await request(app)
        .post('/api/income')
        .send({ description: 'Test', amount: 999.99, source: 'Test' })
        .expect(201);

      const postedIncome = postResponse.body.income;

      // Get income
      const getResponse = await request(app)
        .get('/api/income')
        .expect(200);

      expect(getResponse.body.income).toContainEqual(postedIncome);
    });
  });

  describe('Reset API - POST /api/reset', () => {
    it('should clear all data', async () => {
      // Add some data
      await request(app)
        .post('/api/income')
        .send({ description: 'Salary', amount: 5000 })
        .expect(201);

      await request(app)
        .post('/api/expenses')
        .send({ description: 'Rent', amount: 1000 })
        .expect(201);

      // Verify data exists
      let response = await request(app)
        .get('/api/dashboard')
        .expect(200);

      expect(response.body.totalIncome).toBe(5000);
      expect(response.body.totalExpenses).toBe(1000);

      // Reset
      await request(app)
        .post('/api/reset')
        .expect(200);

      // Verify data is cleared
      response = await request(app)
        .get('/api/dashboard')
        .expect(200);

      expect(response.body.totalIncome).toBe(0);
      expect(response.body.totalExpenses).toBe(0);
      expect(response.body.balance).toBe(0);
    });
  });
});
