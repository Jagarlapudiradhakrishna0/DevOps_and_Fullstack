const express = require('express');
const cors = require('cors');

const app = express();

// In-memory data storage
const dataStore = {
  expenses: [],
  income: [],
};

// Middleware
app.use(cors());
app.use(express.json());

// Internal reset method for testing
app.post('/api/reset', (req, res) => {
  dataStore.expenses = [];
  dataStore.income = [];
  res.status(200).json({ message: 'Data reset successfully' });
});

// GET /api/dashboard - Returns financial summary
app.get('/api/dashboard', (req, res) => {
  const totalIncome = dataStore.income.reduce((sum, item) => sum + item.amount, 0);
  const totalExpenses = dataStore.expenses.reduce((sum, item) => sum + item.amount, 0);
  const balance = totalIncome - totalExpenses;

  res.status(200).json({
    totalIncome,
    totalExpenses,
    balance,
    timestamp: new Date().toISOString(),
  });
});

// GET /api/expenses - Returns all expenses
app.get('/api/expenses', (req, res) => {
  res.status(200).json({
    expenses: dataStore.expenses,
    count: dataStore.expenses.length,
  });
});

// POST /api/expenses - Add a new expense
app.post('/api/expenses', (req, res) => {
  const { description, amount, category } = req.body;

  // Validate input
  if (!description || !amount || amount <= 0) {
    return res.status(400).json({
      error: 'Invalid expense data. Description and positive amount are required.',
    });
  }

  const expense = {
    id: Date.now(),
    description,
    amount: parseFloat(amount),
    category: category || 'General',
    createdAt: new Date().toISOString(),
  };

  dataStore.expenses.push(expense);

  res.status(201).json({
    message: 'Expense added successfully',
    expense,
  });
});

// GET /api/income - Returns all income items
app.get('/api/income', (req, res) => {
  res.status(200).json({
    income: dataStore.income,
    count: dataStore.income.length,
  });
});

// POST /api/income - Add a new income item
app.post('/api/income', (req, res) => {
  const { description, amount, source } = req.body;

  // Validate input
  if (!description || !amount || amount <= 0) {
    return res.status(400).json({
      error: 'Invalid income data. Description and positive amount are required.',
    });
  }

  const incomeItem = {
    id: Date.now(),
    description,
    amount: parseFloat(amount),
    source: source || 'Other',
    createdAt: new Date().toISOString(),
  };

  dataStore.income.push(incomeItem);

  res.status(201).json({
    message: 'Income added successfully',
    income: incomeItem,
  });
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.status(200).json({ status: 'OK', message: 'Backend is running' });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({
    error: 'Internal server error',
    message: err.message,
  });
});

module.exports = app;
