const { sum } = require("./index");

test("adds two numbers", () => {
  expect(sum(2, 3)).toBe(5);
});
